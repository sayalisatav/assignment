<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_basic extends CI_Model {	

	public function _add($table,$data)
	{
		$this->db->insert($table,$data);
		return $this->db->insert_id();		
	}
	public function _get_all_data($table,$condi='',$result_method='')
	{
		 $this->db->select('*')->from($table);
		 if(!empty($condi))
		 {
		 	foreach($condi as $key=>$value)
		 	{
		 		$this->db->where($key,$value);
		 	}
		 }		
		 if($result_method != '')
 		{
 			if($result_method == 'row')
 			{
 				return $this->db->get()->row();
 			}
 			elseif ($result_method == 'row_array')
 			{
 				return $this->db->get()->row_array();
 			}
 			else
 			{
 				return $this->db->get()->result_array();
 			}
 		}
 		else
 		{
 			return $this->db->get()->result_array();
 		}

	}
	public function _update($key,$value,$table,$data)
	{
		$this->db->where($key,$value);
		return $this->db->update($table,$data);		
	}
	public function _delete($key,$value,$table)
	{
		$this->db->where($key,$value);
		return $this->db->delete($table);		
	}
}
