<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	public function __construct()
	{
		parent :: __construct();
		$this->load->model('model_basic');		
	}	
	public function index()
	{			
		$this->load->view('tiny_url_view');		
	}
	public function make_tiny_url()
	{		
		$url = $_POST['url'];		
		if(!empty($url))
		{
			$randomString = $this->random_string(); //generate random string	
			$tiny_url = base_url().$randomString;
			$data = array('url'=>$url,'tiny_url'=>$tiny_url,'created'=>date('Y-m-d H:i:s'));			
			$checkUrlIsPresent = $this->model_basic->_get_all_data('url_master',array('url'=>$url),'row_array');  //check data is present on database	
			if(!empty($checkUrlIsPresent) && $checkUrlIsPresent['tiny_url']!='')
			{				
				echo json_encode($checkUrlIsPresent);
			}
			else
			{
				$urlId = $this->model_basic->_add('url_master',$data);
				if($urlId > 0)
				{					
					echo json_encode($data);
				}
				else
				{
					echo '0';
				}
			}
		}				
	}

	public function random_string()
	{
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';	
		$charactersLength = strlen($characters);
	  	$randomString = '';
	   	for ($i = 0; $i < 12; $i++)
	   	{
	       $randomString .= $characters[rand(0, $charactersLength - 1)];
	   	}
	   	return $randomString;
	}

	public function tiny($tiny_url='')
	{			
		$TinyUri = base_url().$tiny_url;
		$html = $this->model_basic->_get_all_data('url_master',array('tiny_url'=>$TinyUri),'row_array');		
		$this->load->view('site_view',$html);	
	}
	
			
}
