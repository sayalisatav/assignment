<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">	
	<meta http-equiv="X-Frame-Options" content="SAMEORIGIN">
	<title>Welcome to Project</title>
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
	<script type="text/javascript">
		var baseUrl = "<?php echo base_url();?>";
	</script>
</head>
<body>

<div id="container">
	<h1 align="center" >Welcome to Tiny Url!</h1>
	<table align="center" cellpadding="5" bgcolor="#E7E7F7"><tr><td>
	<form action="javascript:void(0)" method="post" id="Tiny-Form">
	Enter a long URL <input type="text" name="url" id="long-url" value="" placeholder="Enter a long URL to make tiny.">
	<button type="submit" onclick="submit_form()">Make TinyURL!</button></form></td></tr>
	</table>
	<div align="center">
	<h1 align="center" id="ShortUrl" style="display:none">Tiny Url </h1>
	<a href="" class="footer" id="short-Url"></p>	
	</a>
	</div>
</div>
<script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
<script src="<?php echo base_url();?>assets/js/tiny_url.js"></script>
</body>
</html>