<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-Frame-Options" content="SAMEORIGIN">
	<title>Welcome to Project</title>
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
</head>
<body>
<iframe src="<?php echo $url;?>" class="my-iframe"></iframe> 
</body>
</html>



