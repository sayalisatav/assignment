
function submit_form()
{	
	var form_data = $('#Tiny-Form').serialize();
	$.ajax({
		url : baseUrl+"home/make_tiny_url",
		type : "post",
		data : form_data,
		success: function(responce)
		{
			if(responce != 0)
			{
				var resdata = $.parseJSON(responce)
				$.each(resdata, function(index,value){							
					if(index == "tiny_url")
					{
						$('#short-Url').attr("href" ,value);
						$('#short-Url').html(value);
						$('#ShortUrl').css('display','block');
						$('#long-url').val('');
						window.open(value, '_blank');	
					}								
				});							
			}
			else
			{
				alert('Please Enter Url.');
			}			
		}	
	});	
}	